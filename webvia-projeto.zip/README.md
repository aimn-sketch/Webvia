# Webvia - Criação de Sites de Alto Padrão

Site institucional e de vendas de serviços da agência **Webvia**, totalmente em português, com foco em alta conversão e estética moderna e minimalista (preto predominante, azul marinho/elétrico e branco).

---

## 🚀 Como hospedar na Netlify

### Opção 1: Arrastar e Soltar (Manual)
1. No seu computador, extraia o arquivo zip.
2. Abra o terminal na pasta e execute:
   ```bash
   npm install
   npm run build
   ```
3. Acesse [app.netlify.com](https://app.netlify.com).
4. Vá em **Sites** e arraste a pasta `dist` gerada para a área de upload da Netlify.
5. Seu site estará no ar em segundos!

### Opção 2: Conectar com GitHub na Netlify
1. Suba este projeto para um repositório no seu GitHub.
2. Na Netlify, clique em **Add new site** > **Import an existing project** > **GitHub**.
3. Selecione o repositório. As configurações já estão prontas no arquivo `netlify.toml`:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Clique em **Deploy**!

---

## 🎨 Como usar no Lovable

1. No Lovable ([lovable.dev](https://lovable.dev)), crie um novo projeto ou importe os arquivos da pasta `src/`, `package.json`, `index.html` e `vite.config.ts`.
2. O projeto utiliza React 19 + Vite + Tailwind CSS v4 + Lucide React.

---

## 💻 Como rodar localmente no seu computador

1. Certifique-se de ter o [Node.js](https://nodejs.org/) instalado (versão 18 ou superior).
2. Instale as dependências:
   ```bash
   npm install
   ```
3. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
4. Abra no navegador: `http://localhost:3000` ou `http://localhost:5173`.

---

## 📱 Contatos Configurados
- **WhatsApp**: (73) 98242-3074
- **Instagram**: @webviaoficial
