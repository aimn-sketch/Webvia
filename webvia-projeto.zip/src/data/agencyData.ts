export interface Project {
  id: string;
  title: string;
  category: string;
  branch: string;
  image: string;
  description: string;
  results: string;
  deliveryTime: string;
  tags: string[];
  features: string[];
  urlPlaceholder?: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  tagline: string;
  description: string;
  targetBranches: string[];
  deliverables: string[];
  deliverySpeed: string;
  highlight?: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  branch: string;
  content: string;
  result: string;
  rating: number;
  avatar: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export const AGENCY_INFO = {
  name: "Webvia",
  tagline: "Tiramos suas ideias do papel e levamos para a internet.",
  aboutText:
    "Acreditamos que todo negócio merece seu espaço na internet. Por isso, transformamos ideias em experiências digitais que conectam marcas a novas oportunidades.",
  mainCta: "Seu site começa aqui",
  instagramHandle: "@webviaoficial",
  instagramUrl: "https://instagram.com/webviaoficial",
  whatsappNumber: "5573982423074",
  whatsappDisplay: "(73) 98242-3074",
  whatsappDefaultMessage: "Olá Webvia! Gostaria de tirar minha ideia do papel e criar o site do meu negócio.",
  sameDayDeliveryMessage: "Preciso de um site com urgência (entrega no mesmo dia). Como funciona?",
  email: "contato@webvia.com.br",
  location: "Atendimento em todo o Brasil",
  cnpj: "48.291.832/0001-90",
};

export const SECTORS = [
  "Clínicas & Saúde",
  "Advocacia & Direito",
  "Restaurantes & Gastronomia",
  "Imobiliárias & Corretores",
  "Engenharia & Construção",
  "Lojas & Comércio",
  "Estética & Barbearias",
  "Educação & Cursos",
  "Prestação de Serviços",
  "Tecnologia & Startups",
  "Outro Ramo",
];

export const SERVICES: ServiceItem[] = [
  {
    id: "landing-page",
    title: "Landing Pages de Alta Conversão",
    tagline: "Focadas 100% em transformar visitantes em clientes pagantes",
    description:
      "Páginas estratégicas de rolagem única desenhadas para tráfego pago (Google Ads, Meta Ads) e captação direta de leads no WhatsApp ou formulário.",
    targetBranches: ["Clínicas", "Advogados", "Infoprodutores", "Serviços Locais", "Eventos"],
    deliverables: [
      "Design exclusivo alinhado à sua marca",
      "Copywriting persuasivo focado em vendas",
      "Botão de WhatsApp direto com mensagem pré-definida",
      "Velocidade máxima no Google PageSpeed",
      "Rastreamento de conversão (Pixel Meta e Google Ads)",
    ],
    deliverySpeed: "Opção no Mesmo Dia",
    highlight: true,
  },
  {
    id: "institucional",
    title: "Sites Institucionais Corporativos",
    tagline: "Autoridade, credibilidade e posicionamento de alto padrão",
    description:
      "A presença digital definitiva para a sua empresa. Apresente seus serviços, história, equipe, diferenciais e portfólio com elegância e sofisticação.",
    targetBranches: ["Empresas B2B", "Escritórios", "Consultorias", "Indústrias", "Construtoras"],
    deliverables: [
      "Múltiplas páginas otimizadas (Início, Sobre, Serviços, Contato)",
      "SEO técnico para indexação prioritária no Google",
      "Área de depoimentos e casos de sucesso",
      "Painel de fácil atualização de conteúdo",
      "Emails profissionais com o domínio da sua empresa",
    ],
    deliverySpeed: "A partir de 24 horas",
  },
  {
    id: "ecommerce-catalog",
    title: "Lojas Virtuais & Catálogos Interativos",
    tagline: "Venda seus produtos 24 horas por dia sem complicação",
    description:
      "Estrutura completa para venda online ou vitrine inteligente com pedido rápido via WhatsApp. Seus clientes encontram o que precisam em 2 cliques.",
    targetBranches: ["Moda & Vestuário", "Restaurantes & Delivery", "Varejo", "Distribuidoras", "Artesanato"],
    deliverables: [
      "Catálogo de produtos com fotos, variações e preços",
      "Integração com Mercado Pago, PIX instantâneo e Cartão",
      "Checkout sem atrito ou checkout direto no WhatsApp",
      "Cálculo automático de frete e envio",
      "Controle de estoque simples e visual",
    ],
    deliverySpeed: "A partir de 48 horas",
  },
  {
    id: "agendamento",
    title: "Sites com Agendamento Online",
    tagline: "Sua agenda cheia sem você perder tempo respondendo mensagens",
    description:
      "Solução inteligente para profissionais que vendem horários. O cliente visualiza a grade disponível, escolhe o serviço e confirma a consulta ou sessão.",
    targetBranches: ["Médicos & Dentistas", "Salões & Spas", "Psicólogos", "Personal Trainers", "Consultores"],
    deliverables: [
      "Calendário interativo integrado à sua rotina",
      "Lembretes automáticos via WhatsApp e E-mail",
      "Opção de pagamento antecipado do sinal ou consulta",
      "Sincronização com Google Calendar",
      "Página otimizada para celulares",
    ],
    deliverySpeed: "A partir de 24 horas",
  },
  {
    id: "redesign",
    title: "Redesign & Otimização de Performance",
    tagline: "Seu site atual é antigo ou não gera vendas? Nós transformamos",
    description:
      "Modernizamos a identidade do seu site antigo, corrigimos problemas de lentidão e adaptamos a estrutura para os padrões de conversão modernos.",
    targetBranches: ["Qualquer empresa com site defasado ou lento"],
    deliverables: [
      "Migração sem queda de tráfego existente",
      "Aceleração extrema do tempo de carregamento",
      "Adaptação para smartphones modernos",
      "Correção de links quebrados e falhas visuais",
      "Design alinhado às referências mundiais de 2026",
    ],
    deliverySpeed: "Opção no Mesmo Dia",
  },
  {
    id: "express",
    title: "Desenvolvimento Express (Mesmo Dia)",
    tagline: "Lançamento recorde para quem não pode perder oportunidades",
    description:
      "Nosso time entra em modo força-tarefa exclusiva para estruturar, diagramar e publicar sua presença digital em tempo recorde sem abrir mão do acabamento premium.",
    targetBranches: ["Empresas com lançamentos urgentes", "Promoções de oportunidade", "Feiras e eventos"],
    deliverables: [
      "Prioridade máxima na fila de produção",
      "Briefing rápido de 15 minutos via WhatsApp",
      "Site no ar em até 12 a 24 horas úteis",
      "Estrutura completa pronta para rodar anúncios",
      "Garantia de funcionamento imediato",
    ],
    deliverySpeed: "No Mesmo Dia (Recorde)",
    highlight: true,
  },
];

export const PORTFOLIO: Project[] = [
  {
    id: "medicina-drgabriel",
    title: "Dr. Gabriel Rossi - Medicina Integrativa",
    category: "Landing Page de Alta Conversão",
    branch: "Saúde & Clínicas",
    image: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80",
    description:
      "Site com posicionamento premium para médico especialista. Visual sóbrio, depoimentos em vídeo e fluxo rápido para marcação de consultas particulares.",
    results: "+280% em pedidos de consulta particular no primeiro mês",
    deliveryTime: "Entregue em 1 dia",
    tags: ["Saúde", "Consultas", "Design Premium", "Mobile First"],
    features: ["Botão WhatsApp inteligente", "Apresentação de tratamentos", "SEO para busca local"],
  },
  {
    id: "bistro-oasis",
    title: "Oásis Gastronomia & Parrilla",
    category: "Site Institucional + Cardápio Interativo",
    branch: "Restaurantes & Gastronomia",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
    description:
      "Site elegante com fotos em alta definição dos pratos, cardápio digital interativo sem necessidade de baixar PDF e reserva de mesas em 1 toque.",
    results: "Redução de 45% nos custos com taxas de plataformas terceiras",
    deliveryTime: "Entregue no mesmo dia",
    tags: ["Gastronomia", "Cardápio QR Code", "Reservas", "Entrega Expressa"],
    features: ["Cardápio com fotos dinâmicas", "Integração Google Maps", "Reserva de mesa direta"],
  },
  {
    id: "advocacia-vanguarda",
    title: "Vanguarda Advocacia Empresarial",
    category: "Site Corporativo",
    branch: "Advocacia & Direito",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80",
    description:
      "Presença digital robusta transmitindo solidez jurídica para captação de clientes corporativos e resolução tributária.",
    results: "+15 novas empresas atendidas nos primeiros 60 dias de lançamento",
    deliveryTime: "Entregue em 2 dias",
    tags: ["Direito", "Corporativo", "B2B", "SEO Jurídico"],
    features: ["Áreas de atuação detalhadas", "Artigos e publicações", "Formulário de triagem seguro"],
  },
  {
    id: "imoveis-habitat",
    title: "Habitat Empreendimentos Prime",
    category: "Catálogo Imobiliário & Lançamentos",
    branch: "Imobiliárias & Corretores",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80",
    description:
      "Plataforma veloz para apresentação de imóveis de alto padrão, tour em fotos 360 e filtro intuitivo por região e metragem.",
    results: "Geração de mais de 80 leads qualificados por semana",
    deliveryTime: "Entregue em 3 dias",
    tags: ["Imobiliário", "Alto Padrão", "Filtro Rápido", "Leads"],
    features: ["Galeria interativa de fotos", "Calculadora de financiamento", "Contato com corretor"],
  },
  {
    id: "lumina-estetica",
    title: "Lúmina Estética Avançada",
    category: "Landing Page + Agendamento",
    branch: "Estética & Barbearias",
    image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1200&q=80",
    description:
      "Site minimalista e sofisticado para clínica de harmonização facial e tratamentos corporais com antes e depois e avaliações de clientes.",
    results: "Agenda preenchida com 3 semanas de antecedência",
    deliveryTime: "Entregue no mesmo dia",
    tags: ["Beleza", "Agendamento", "Design Clean", "Conversão"],
    features: ["Galeria de procedimentos", "Avaliações 5 estrelas", "Ligação direta e WhatsApp"],
  },
  {
    id: "urban-store",
    title: "Urban Mode Concept Store",
    category: "E-commerce & Vitrine Virtual",
    branch: "Lojas & Comércio",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80",
    description:
      "Loja rápida focada em vendas de vestuário urbano com finalização de pedido via PIX com aprovação instantânea.",
    results: "R$ 38.000 faturados na primeira semana de lançamento da nova coleção",
    deliveryTime: "Entregue em 2 dias",
    tags: ["E-commerce", "Moda", "PIX Automático", "Mobile"],
    features: ["Checkout transparente", "Guia de tamanhos interativo", "Integração Correios e Melhor Envio"],
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "1",
    name: "Dr. Gabriel Rossi",
    role: "Médico e Proprietário",
    company: "Instituto Rossi",
    branch: "Saúde & Medicina",
    content:
      "O atendimento da Webvia superou todas as expectativas. Minha agenda de consultas particulares estava dependente de indicações lentas. Com o novo site no ar, passamos a receber pacientes qualificados todos os dias pelo WhatsApp.",
    result: "+280% em consultas particulares",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=200&q=80",
  },
  {
    id: "2",
    name: "Renata Vasconcelos",
    role: "Sócia-Diretora",
    company: "Vasconcelos & Prado Advogados",
    branch: "Advocacia Empresarial",
    content:
      "Precisávamos de um site corporativo que passasse credibilidade imediata para diretores de grandes empresas. O design ficou impecável, extremamente limpo e formal na medida certa. O retorno foi imediato.",
    result: "Fechamento de 4 contratos de assessoria contínua",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80",
  },
  {
    id: "3",
    name: "Carlos Eduardo Menezes",
    role: "Fundador",
    company: "Oásis Parrilla Bar",
    branch: "Gastronomia",
    content:
      "Eu precisava de um site no mesmo dia porque íamos inaugurar nossa segunda unidade no sábado. Contatei a Webvia pela manhã e no fim da tarde o site já estava online, com cardápio, fotos e botão de reservas rodando perfeitamente!",
    result: "Entrega confirmada no mesmo dia",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80",
  },
  {
    id: "4",
    name: "Fernanda Albuquerque",
    role: "CEO & Esteticista",
    company: "Lúmina Clinic",
    branch: "Estética & Beleza",
    content:
      "Antes eu tinha vergonha de passar o link do meu site antigo porque era lento e feio no celular. A Webvia refez tudo com um bom gosto absurdo. Minhas clientes comentam que o site passa ar de luxo internacional.",
    result: "Taxa de conversão de cliques em 38%",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80",
  },
];

export const DIFFERENTIALS = [
  {
    number: "01",
    title: "Entrega no Mesmo Dia",
    description:
      "Para negócios que não podem esperar semanas. Temos processos validados que permitem colocar seu site no ar em até poucas horas com máxima qualidade.",
  },
  {
    number: "02",
    title: "Especialista em Todos os Ramos",
    description:
      "Clínicas, gastronomia, escritórios de advocacia, lojas, prestadores de serviços ou indústrias. Adaptamos a linguagem visual e estratégia exata para o seu público.",
  },
  {
    number: "03",
    title: "Foco Obsessivo em Faturamento",
    description:
      "Não fazemos site só para 'ficar bonito'. Cada botão, título e imagem é posicionado estrategicamente para levar o visitante a chamar você e comprar.",
  },
  {
    number: "04",
    title: "Design Responsivo & Veloz",
    description:
      "Mais de 85% dos seus clientes vão abrir o site no smartphone. Garantimos que sua página carregue instantaneamente em qualquer conexão 4G/5G.",
  },
];

export const HOW_IT_WORKS = [
  {
    step: "01",
    title: "Briefing Rápido de 10 Minutos",
    description: "Você nos conta sobre seu negócio, seus diferenciais e o objetivo principal. Pode ser direto pelo WhatsApp.",
  },
  {
    step: "02",
    title: "Criação & Desenvolvimento Estratégico",
    description: "Nossa equipe desenvolve a estrutura, o design de alto padrão e os textos persuasivos pensados para o seu segmento.",
  },
  {
    step: "03",
    title: "Aprovação & Ajustes Finos",
    description: "Você visualiza o site funcionando no link de prévia, confere cada detalhe e fazemos qualquer ajuste que desejar.",
  },
  {
    step: "04",
    title: "Lançamento Oficial & Vendas",
    description: "Configuramos seu domínio oficial (ex: suarempresa.com.br), botão de WhatsApp, rastreadores e seu site começa a vender.",
  },
];

export const FAQS: FAQItem[] = [
  {
    question: "Como funciona a entrega no mesmo dia?",
    answer:
      "Disponibilizamos uma modalidade expressa onde nossa equipe entra em regime de dedicação exclusiva para o seu projeto. Realizamos o alinhamento rápido pelo WhatsApp pela manhã e, até o fim do dia, seu site estruturado, otimizado para celulares e pronto para receber clientes é publicado.",
  },
  {
    question: "Vocês atendem o meu ramo de atividade?",
    answer:
      "Sim, somos especialistas em desenvolver sites para todo tipo de ramo: consultórios e clínicas de saúde, escritórios de advocacia, restaurantes e bares, imobiliárias, serviços locais, comércio eletrônico, consultorias empresariais, estúdios de beleza e muito mais. Estudamos os concorrentes do seu nicho para entregar uma proposta acima da média do mercado.",
  },
  {
    question: "Preciso já ter os textos e imagens prontos?",
    answer:
      "Não se preocupe se ainda não tiver. Nossa equipe desenvolve a estrutura textual persuasiva (copywriting) adequada ao seu ramo e seleciona fotos profissionais em alta resolução que valorizam a identidade da sua marca.",
  },
  {
    question: "O site funcionará perfeitamente em celulares?",
    answer:
      "100%. Todo projeto da Webvia é desenvolvido com metodologia Mobile-First. Isso garante navegação fluida, botões acessíveis ao toque, carregamento em menos de 1 segundo e layout perfeito em qualquer tela de iPhone ou Android.",
  },
  {
    question: "Terei que pagar mensalidade para a Webvia?",
    answer:
      "Não cobramos mensalidades obrigatórias de desenvolvimento. O site é 100% de propriedade do seu negócio. Você só arca com custos normais da internet (seu domínio .com.br anual e a hospedagem dos arquivos, que auxiliamos na configuração pelo menor custo).",
  },
  {
    question: "Como os clientes vão entrar em contato comigo através do site?",
    answer:
      "Inserimos botões flutuantes e fixos direcionando direto para o seu WhatsApp oficial com mensagens personalizadas pré-configuradas (ex: 'Olá! Vi o site e quero um orçamento'), facilitando o fechamento rápido de vendas no seu celular.",
  },
];
