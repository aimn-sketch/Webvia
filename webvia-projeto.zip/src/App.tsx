/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Services } from "./components/Services";
import { Portfolio } from "./components/Portfolio";
import { Testimonials } from "./components/Testimonials";
import { FaqSection } from "./components/FaqSection";
import { ProjectSimulator } from "./components/ProjectSimulator";
import { ContactSection } from "./components/ContactSection";
import { FloatingWhatsApp } from "./components/FloatingWhatsApp";
import { Footer } from "./components/Footer";

export default function App() {
  const [selectedService, setSelectedService] = useState<string | undefined>(undefined);
  const [selectedSector, setSelectedSector] = useState<string | undefined>(undefined);

  const scrollToContact = (sector?: string, service?: string) => {
    if (sector) setSelectedSector(sector);
    if (service) setSelectedService(service);

    const contactElement = document.getElementById("contato");
    if (contactElement) {
      contactElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToPortfolio = () => {
    const portfolioElement = document.getElementById("portfolio");
    if (portfolioElement) {
      portfolioElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSelectService = (serviceName: string) => {
    setSelectedService(serviceName);
    scrollToContact(undefined, serviceName);
  };

  const handleRequestSimilarProject = (projectTitle: string, branch: string) => {
    setSelectedService(`Projeto estilo: ${projectTitle}`);
    setSelectedSector(branch);
    scrollToContact(branch, `Projeto estilo: ${projectTitle}`);
  };

  const handleSimulationApplied = (sector: string, projectType: string) => {
    setSelectedSector(sector);
    setSelectedService(projectType);
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col selection:bg-blue-600 selection:text-white">
      {/* 1. Header / Navigation */}
      <Navbar onOpenContact={() => scrollToContact()} />

      <main className="flex-1">
        {/* 1. Seção inicial impactante (Hero) */}
        <Hero
          onStartProject={() => scrollToContact()}
          onExplorePortfolio={scrollToPortfolio}
        />

        {/* 2. Sobre / Quem sou */}
        <About onStartProject={() => scrollToContact()} />

        {/* 3. Serviços */}
        <Services onSelectService={handleSelectService} />

        {/* 4. Portfólio / Projetos */}
        <Portfolio onRequestSimilar={handleRequestSimilarProject} />

        {/* 5. Depoimentos */}
        <Testimonials />

        {/* Interactive Bridge: Simulador & Dúvidas Frequentes */}
        <ProjectSimulator onApplySimulation={handleSimulationApplied} />
        <FaqSection />

        {/* 6. Formulário de contato */}
        <ContactSection
          initialService={selectedService}
          initialSector={selectedSector}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* 7. WhatsApp flutuante */}
      <FloatingWhatsApp />
    </div>
  );
}
