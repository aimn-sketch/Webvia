import { useState, useEffect } from "react";
import { AGENCY_INFO } from "../data/agencyData";
import { MessageCircle, X, Sparkles } from "lucide-react";

export function FloatingWhatsApp() {
  const [showTooltip, setShowTooltip] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    // Show inviting tooltip after 3 seconds
    const timer = setTimeout(() => {
      if (!isDismissed) {
        setShowTooltip(true);
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [isDismissed]);

  const whatsappUrl = `https://wa.me/${AGENCY_INFO.whatsappNumber}?text=${encodeURIComponent(
    AGENCY_INFO.whatsappDefaultMessage
  )}`;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Tooltip Popup */}
      {showTooltip && !isDismissed && (
        <div className="mb-3 max-w-xs bg-[#0A0F1D] rounded-2xl p-4 shadow-2xl border border-white/15 text-white animate-in slide-in-from-bottom-3 duration-300 relative">
          <button
            onClick={() => {
              setShowTooltip(false);
              setIsDismissed(true);
            }}
            className="absolute top-2 right-2 p-1 text-slate-400 hover:text-white rounded-full cursor-pointer"
            aria-label="Fechar mensagem"
          >
            <X className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="space-y-1">
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Especialista Webvia</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                Olá! Quer tirar sua ideia do papel hoje mesmo? Fale com a gente no WhatsApp.
              </p>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block text-[11px] font-bold text-emerald-400 hover:text-emerald-300 underline mt-1"
              >
                Iniciar conversa imediata →
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Conversar com a Webvia no WhatsApp"
        className="group relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-xl shadow-emerald-500/30 hover:shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-emerald-400"
      >
        {/* Pulsing ring */}
        <span className="absolute -inset-1 rounded-full bg-emerald-400 opacity-40 animate-ping pointer-events-none" />

        <MessageCircle className="w-7 h-7 sm:w-8 sm:h-8" />

        {/* Status Dot */}
        <span className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-white" />
      </a>
    </div>
  );
}
