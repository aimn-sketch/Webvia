import { AGENCY_INFO } from "../data/agencyData";
import { Instagram, ArrowUp, Heart, ShieldCheck, Phone, MapPin, Download } from "lucide-react";

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-[#020408] text-white pt-20 pb-12 border-t border-white/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-16 border-b border-white/10">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-white/15 to-white/5 border border-white/20 flex items-center justify-center text-white font-bold text-xl tracking-tighter">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-300">
                  W
                </span>
              </div>
              <span className="text-2xl font-bold tracking-tight text-white font-display">
                Webvia
              </span>
            </div>

            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              "{AGENCY_INFO.tagline}"
            </p>

            <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
              Agência especializada em criação de sites de alto padrão para empresas e negócios que desejam expandir
              seu faturamento. Entrega expressa com opção no mesmo dia.
            </p>

            {/* Socials */}
            <div className="pt-2 flex items-center gap-3">
              <a
                href={AGENCY_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-semibold transition-all group"
              >
                <Instagram className="w-4 h-4 text-pink-400 group-hover:scale-110 transition-transform" />
                <span>{AGENCY_INFO.instagramHandle}</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">
              Navegação
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">
                  Sobre a Webvia
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">
                  Nossos Serviços
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">
                  Portfólio & Ramos
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">
                  Depoimentos
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">
                  Solicitar Proposta
                </a>
              </li>
            </ul>
          </div>

          {/* Sectors Served */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">
              Ramos Atendidos
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Saúde, Clínicas & Médicos</li>
              <li>Restaurantes & Gastronomia</li>
              <li>Advocacia & Jurídico</li>
              <li>Imobiliárias & Corretores</li>
              <li>Lojas & E-commerces</li>
              <li>Prestadores de Serviços</li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">
              Atendimento Brasil
            </h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Atendimento digital em todo o Brasil</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`https://wa.me/${AGENCY_INFO.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  WhatsApp: {AGENCY_INFO.whatsappDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Instagram className="w-4 h-4 text-pink-400 shrink-0" />
                <a
                  href={AGENCY_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  Instagram: {AGENCY_INFO.instagramHandle}
                </a>
              </div>
              <div className="flex items-center gap-2 pt-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>CNPJ: {AGENCY_INFO.cnpj}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Webvia. Todos os direitos reservados. Foco em alta conversão e resultado.</p>

          <div className="flex items-center gap-3">
            <a
              href="/webvia-projeto.zip"
              download="webvia-projeto.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/40 text-cyan-300 border border-blue-500/30 transition-all font-semibold"
              title="Baixar arquivo ZIP completo do projeto"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar ZIP do Projeto</span>
            </a>

            <button
              onClick={scrollToTop}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <span>Voltar ao topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
