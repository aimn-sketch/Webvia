import { useState } from "react";
import { AGENCY_INFO } from "../data/agencyData";
import {
  ArrowRight,
  Zap,
  CheckCircle2,
  TrendingUp,
  Smartphone,
  ShieldCheck,
  Sparkles,
  MousePointerClick,
  Layers,
} from "lucide-react";

interface HeroProps {
  onStartProject: (sector?: string) => void;
  onExplorePortfolio: () => void;
}

export function Hero({ onStartProject, onExplorePortfolio }: HeroProps) {
  const [activeTab, setActiveTab] = useState<"clinica" | "restaurante" | "direito" | "loja">("clinica");

  const previewTabs = [
    { id: "clinica" as const, label: "Saúde & Clínicas", title: "Clínica Médica & Longevidade", metric: "+280% agendamentos" },
    { id: "restaurante" as const, label: "Gastronomia", title: "Oásis Bistrô & Parrilla", metric: "Economia em comissões" },
    { id: "direito" as const, label: "Advocacia", title: "Vanguarda Direito Empresarial", metric: "+15 contratos B2B" },
    { id: "loja" as const, label: "Lojas & Varejo", title: "Concept Store Elegance", metric: "Vendas via PIX 24h" },
  ];

  const tabDetails = {
    clinica: {
      headline: "Cuidado médico de excelência para quem busca qualidade de vida",
      sub: "Agendamento rápido de consultas particulares com confirmação no WhatsApp.",
      tag: "Medicina Integrativa",
      cta: "Agendar Consulta",
      badge: "Agenda Online Ativa",
      color: "from-blue-600 to-cyan-500",
      accent: "#0284c7",
    },
    restaurante: {
      headline: "A alta gastronomia artesanal com sabores memoráveis",
      sub: "Cardápio inteligente por QR Code e reserva antecipada sem fila de espera.",
      tag: "Gastronomia Contemporânea",
      cta: "Ver Cardápio & Reservar",
      badge: "Mesas Disponíveis",
      color: "from-amber-600 to-orange-500",
      accent: "#d97706",
    },
    direito: {
      headline: "Assessoria jurídica estratégica para blindar sua empresa",
      sub: "Defesa preventiva tributária, contratual e societária para negócios modernos.",
      tag: "Advocacia B2B",
      cta: "Falar com Especialista",
      badge: "Atendimento Corporativo",
      color: "from-slate-700 to-slate-900",
      accent: "#1e293b",
    },
    loja: {
      headline: "Coleção exclusiva desenvolvida com matérias-primas nobres",
      sub: "Frete expresso para todo o Brasil e pagamento facilitado no PIX ou cartão.",
      tag: "Moda & Lifestyle",
      cta: "Comprar Coleção",
      badge: "Envio Imediato",
      color: "from-rose-600 to-purple-600",
      accent: "#be185d",
    },
  };

  const currentPreview = tabDetails[activeTab];

  return (
    <section id="inicio" className="relative bg-black text-white pt-16 pb-24 md:pt-24 md:pb-32 overflow-hidden">
      {/* Subtle Background Glow & Pattern */}
      <div className="absolute inset-0 dark-grid-pattern opacity-10 pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-blue-700/20 via-[#0A2540]/25 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Grid: Headline + Visual Mockup */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Persuasive Copy */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            {/* Speed & Specialization Badge */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#0A1224] border border-blue-500/30 text-slate-200 text-xs sm:text-sm font-medium backdrop-blur-sm">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-white font-semibold flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400 inline" />
                Entrega no mesmo dia disponível
              </span>
              <span className="text-slate-500 hidden sm:inline">|</span>
              <span className="text-slate-300 hidden sm:inline">Sites para todo tipo de ramo</span>
            </div>

            {/* Tagline & Headline */}
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] font-display text-white">
                Tiramos suas ideias do papel e{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-300 to-white">
                  levamos para a internet.
                </span>
              </h1>
              <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Criamos sites de alto padrão, velozes e focados em gerar vendas para empresas e estabelecimentos que querem
                expandir seu faturamento. Design exclusivo, sem enrolação e pronto para faturar.
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => onStartProject()}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 bg-blue-600 hover:bg-blue-500 text-white font-bold px-8 py-4 rounded-xl text-base shadow-xl shadow-blue-950/80 hover:shadow-2xl border border-blue-400/40 transition-all duration-200 active:scale-98 cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-400 group"
              >
                <span>{AGENCY_INFO.mainCta}</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExplorePortfolio}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-black hover:bg-[#0A162B] text-white font-semibold px-6 py-4 rounded-xl text-base border border-white/20 hover:border-blue-500/50 transition-all duration-200 cursor-pointer shadow-lg"
              >
                <Layers className="w-4 h-4 text-cyan-300" />
                <span>Ver Portfólio & Ramos</span>
              </button>
            </div>

            {/* Key Value Points */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 border-t border-white/10 text-left">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300">
                  <span className="font-semibold text-white block">100% Responsivo</span>
                  Perfeito em qualquer celular
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300">
                  <span className="font-semibold text-white block">Botão WhatsApp</span>
                  Contato em 1 clique
                </div>
              </div>
              <div className="flex items-start gap-2 col-span-2 sm:col-span-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300">
                  <span className="font-semibold text-white block">Otimizado para o Google</span>
                  SEO técnico estruturado
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: High-End Live Interactive Site Preview */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              {/* Sector selector pills above preview */}
              <div className="flex items-center justify-between gap-1 mb-3 overflow-x-auto pb-1 no-scrollbar">
                <span className="text-xs text-slate-400 font-medium shrink-0 flex items-center gap-1 mr-1">
                  <MousePointerClick className="w-3.5 h-3.5 text-cyan-400" />
                  Ramos:
                </span>
                <div className="flex items-center gap-1.5">
                  {previewTabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`text-xs px-2.5 py-1 rounded-md transition-all font-medium whitespace-nowrap cursor-pointer ${
                        activeTab === tab.id
                          ? "bg-white text-black font-bold shadow-md"
                          : "bg-black/60 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Main Desktop Browser Frame */}
              <div className="rounded-2xl bg-black border border-white/15 shadow-2xl overflow-hidden backdrop-blur-xl">
                {/* Browser top chrome */}
                <div className="bg-[#020408] px-4 py-3 border-b border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                    <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                    <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  </div>
                  <div className="bg-white/5 text-slate-300 text-[11px] font-mono px-3 py-1 rounded-md flex items-center gap-1.5 border border-white/10">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                    <span>webvia.com.br/cliente-demo</span>
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>SSL Seguro</span>
                  </div>
                </div>

                {/* Simulated Webpage Content */}
                <div className="p-6 bg-gradient-to-b from-[#020408] via-[#050D1D] to-[#0A1830] min-h-[340px] flex flex-col justify-between relative transition-all duration-300">
                  {/* Watermark brand tag */}
                  <div className="flex items-center justify-between text-xs pb-4 border-b border-white/10">
                    <span className="font-bold text-white tracking-tight flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      {tabDetails[activeTab].tag}
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 font-medium">
                      {tabDetails[activeTab].badge}
                    </span>
                  </div>

                  {/* Body of simulated site */}
                  <div className="py-6 space-y-4">
                    <div className="inline-block text-[11px] font-semibold tracking-wider text-cyan-300 uppercase">
                      Site Criado pela Webvia
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white font-display leading-tight">
                      {currentPreview.headline}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {currentPreview.sub}
                    </p>

                    <div className="flex items-center gap-3 pt-2">
                      <div className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md flex items-center gap-1.5 border border-blue-400/30">
                        <span>{currentPreview.cta}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Carrega em 0.6s</span>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Stats Banner in preview */}
                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1 text-emerald-400 font-semibold">
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>{previewTabs.find((t) => t.id === activeTab)?.metric}</span>
                    </div>
                    <span className="text-slate-400 text-[11px]">Taxa de conversão recorde</span>
                  </div>
                </div>
              </div>

              {/* Floating Mobile Phone Mockup Overlay */}
              <div className="absolute -bottom-8 -right-4 sm:-right-6 w-36 sm:w-44 bg-[#051321] rounded-2xl p-2 border-2 border-white/20 shadow-2xl backdrop-blur-md hidden sm:block">
                <div className="rounded-xl bg-slate-950 p-2.5 text-left border border-white/10 space-y-1.5">
                  <div className="w-6 h-1 bg-white/20 rounded-full mx-auto mb-1.5" />
                  <div className="text-[9px] font-bold text-white flex items-center justify-between">
                    <span>Versão Celular</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  </div>
                  <div className="text-[8px] text-slate-300 leading-tight">
                    Otimizado para WhatsApp & cliques rápidos.
                  </div>
                  <div className="w-full py-1 bg-emerald-500 text-slate-950 rounded text-[9px] font-bold text-center mt-1">
                    Chamar no WhatsApp
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Impact Bar Numbers */}
        <div className="mt-20 pt-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-8 text-center md:text-left">
          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-extrabold text-white font-display">No Mesmo Dia</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">Prazo de entrega expressa</div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-extrabold text-white font-display">100%</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">Dos ramos e nichos atendidos</div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-extrabold text-white font-display">+180</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">Empresas e negócios transformados</div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl sm:text-4xl font-extrabold text-white font-display">99.8%</div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium">Índice de aprovação de clientes</div>
          </div>
        </div>
      </div>
    </section>
  );
}
