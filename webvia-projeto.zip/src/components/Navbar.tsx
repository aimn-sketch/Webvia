import { useState, useEffect } from "react";
import { AGENCY_INFO } from "../data/agencyData";
import { Instagram, ArrowRight, Menu, X, Zap } from "lucide-react";

interface NavbarProps {
  onOpenContact: (sector?: string) => void;
}

export function Navbar({ onOpenContact }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Início", href: "#inicio" },
    { label: "Sobre", href: "#sobre" },
    { label: "Serviços", href: "#servicos" },
    { label: "Portfólio", href: "#portfolio" },
    { label: "Depoimentos", href: "#depoimentos" },
    { label: "Diferenciais", href: "#diferenciais" },
    { label: "Contato", href: "#contato" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? "bg-black/95 backdrop-blur-md shadow-2xl border-b border-white/10 py-3.5"
            : "bg-black py-5 border-b border-white/5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo & Brand */}
            <a
              href="#inicio"
              className="flex items-center gap-3 group focus-visible:outline-2 focus-visible:outline-white rounded"
              aria-label="Webvia Home"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-950 via-slate-950 to-black border border-blue-500/40 flex items-center justify-center text-white font-bold text-xl tracking-tighter group-hover:border-cyan-400/60 shadow-lg shadow-blue-950 transition-colors">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-300">
                  W
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold tracking-tight text-white font-display">
                  Webvia
                </span>
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-medium">
                  Criação de Sites
                </span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8" aria-label="Navegação principal">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="text-sm font-medium text-slate-300 hover:text-white transition-colors focus-visible:outline-2 focus-visible:outline-white rounded py-1"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* Actions: Instagram & CTA */}
            <div className="hidden sm:flex items-center gap-4">
              <a
                href={AGENCY_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white px-3 py-2 rounded-lg hover:bg-white/5 transition-all"
                title="Siga @webviaoficial no Instagram"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
                <span className="font-medium text-slate-300">@webviaoficial</span>
              </a>

              <button
                onClick={() => onOpenContact()}
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-5 py-2.5 rounded-lg text-sm font-bold transition-all duration-200 shadow-lg shadow-blue-900/40 border border-blue-400/30 active:scale-98 cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <span>{AGENCY_INFO.mainCta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors focus-visible:outline-white"
                aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#050508] border-b border-white/10 px-4 pt-3 pb-6 animate-in slide-in-from-top-4 duration-200">
            <div className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-base font-medium text-slate-200 hover:text-white py-2 border-b border-white/5"
                >
                  {link.label}
                </a>
              ))}

              <div className="pt-2 flex flex-col gap-3">
                <a
                  href={AGENCY_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-slate-300 hover:text-white py-2"
                >
                  <Instagram className="w-4 h-4 text-pink-400" />
                  <span>Instagram: {AGENCY_INFO.instagramHandle}</span>
                </a>

                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenContact();
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-lg font-bold text-sm shadow-md"
                >
                  <span>{AGENCY_INFO.mainCta}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Top Banner ticker for delivery guarantee */}
      <div className="bg-[#020204] text-slate-300 text-xs py-2 px-4 border-b border-white/5 relative z-30 pt-20 sm:pt-24">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-medium">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>
              <strong className="text-white">Opção de Entrega no Mesmo Dia</strong> disponível para projetos expressos.
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-400 hidden sm:flex">
            <span>Atendimento em todo o Brasil</span>
            <span>•</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Projetos aceitos hoje
            </span>
          </div>
        </div>
      </div>
    </>
  );
}
