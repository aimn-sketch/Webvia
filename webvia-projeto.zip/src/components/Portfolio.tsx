import { useState } from "react";
import { PORTFOLIO, Project } from "../data/agencyData";
import {
  ExternalLink,
  Clock,
  TrendingUp,
  X,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Smartphone,
  ShieldCheck,
} from "lucide-react";

interface PortfolioProps {
  onRequestSimilar: (projectTitle: string, branch: string) => void;
}

export function Portfolio({ onRequestSimilar }: PortfolioProps) {
  const [selectedBranch, setSelectedBranch] = useState<string>("Todos");
  const [activeModalProject, setActiveModalProject] = useState<Project | null>(null);

  const branches = [
    "Todos",
    "Saúde & Clínicas",
    "Restaurantes & Gastronomia",
    "Advocacia & Direito",
    "Imobiliárias & Corretores",
    "Estética & Barbearias",
    "Lojas & Comércio",
  ];

  const filteredProjects =
    selectedBranch === "Todos"
      ? PORTFOLIO
      : PORTFOLIO.filter((p) => p.branch === selectedBranch);

  return (
    <section id="portfolio" className="py-24 sm:py-32 bg-[#070B14] text-white relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
            <span className="w-8 h-[2px] bg-cyan-400" />
            Portfólio & Casos de Sucesso
            <span className="w-8 h-[2px] bg-cyan-400" />
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
            Projetos reais criados para gerar resultados e expandir faturamentos.
          </h2>

          <p className="text-lg text-slate-300 leading-relaxed font-normal">
            Veja exemplos de sites desenvolvidos pela Webvia em diferentes segmentos, com acabamento refinado e
            métricas comprovadas de captação de clientes.
          </p>
        </div>

        {/* Branch Filter Tabs */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-14" role="tablist">
          {branches.map((branch) => (
            <button
              key={branch}
              onClick={() => setSelectedBranch(branch)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                selectedBranch === branch
                  ? "bg-blue-600 text-white font-bold shadow-lg shadow-blue-900/40 border border-blue-400/40 scale-102"
                  : "bg-black text-slate-300 border border-white/10 hover:border-blue-500/40 hover:text-white"
              }`}
              role="tab"
              aria-selected={selectedBranch === branch}
            >
              {branch}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => setActiveModalProject(project)}
              className="group cursor-pointer rounded-2xl overflow-hidden border border-white/10 bg-[#0A0F1D] hover:border-blue-500/50 transition-all duration-300 hover:shadow-2xl hover:shadow-black/90 flex flex-col justify-between"
            >
              {/* Image Frame */}
              <div className="relative aspect-video overflow-hidden bg-black">
                <img
                  src={project.image}
                  alt={`Site desenvolvido para ${project.title}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#020408] via-[#050D1C]/60 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                {/* Delivery Time Badge */}
                <div className="absolute top-3 left-3">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/85 text-white text-[11px] font-semibold backdrop-blur-md border border-white/20">
                    <Clock className="w-3 h-3 text-amber-300" />
                    {project.deliveryTime}
                  </span>
                </div>

                <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="p-2 rounded-full bg-white text-black shadow-md flex items-center justify-center">
                    <ExternalLink className="w-3.5 h-3.5" />
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[11px] font-medium text-cyan-300 uppercase tracking-wider block">
                    {project.branch}
                  </span>
                  <h3 className="text-lg font-bold font-display tracking-tight text-white line-clamp-1">
                    {project.title}
                  </h3>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-3">
                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Highlights tag */}
                  <div className="flex flex-wrap gap-1">
                    {project.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="text-[11px] px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300 font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom Metric */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                    <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                    <span className="line-clamp-1">{project.results}</span>
                  </div>

                  <span className="text-xs font-bold text-white group-hover:text-cyan-300 flex items-center gap-1">
                    Detalhes <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal: Project Details Preview */}
        {activeModalProject && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
          >
            <div className="bg-[#0A0F1D] text-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/15 p-6 sm:p-8 relative">
              {/* Close Button */}
              <button
                onClick={() => setActiveModalProject(null)}
                className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Fechar modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Modal Content */}
              <div className="space-y-6">
                <div>
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest block mb-1">
                    {activeModalProject.branch} • {activeModalProject.category}
                  </span>
                  <h3 id="modal-title" className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                    {activeModalProject.title}
                  </h3>
                </div>

                {/* Image Showcase */}
                <div className="relative rounded-2xl overflow-hidden aspect-video bg-black border border-white/10">
                  <img
                    src={activeModalProject.image}
                    alt={activeModalProject.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-3 left-3 bg-black/85 backdrop-blur-md px-3 py-1.5 rounded-lg text-xs font-medium text-white flex items-center gap-2 border border-white/15">
                    <Clock className="w-3.5 h-3.5 text-amber-300" />
                    <span>{activeModalProject.deliveryTime}</span>
                  </div>
                </div>

                {/* Description & Impact */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Visão Geral & Estratégia
                    </h4>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      {activeModalProject.description}
                    </p>
                  </div>

                  {/* Verifiable Result */}
                  <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-start gap-3">
                    <TrendingUp className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-xs font-bold text-emerald-300 block">
                        Resultado de Faturamento Comprovado:
                      </span>
                      <p className="text-sm font-bold text-emerald-400">
                        {activeModalProject.results}
                      </p>
                    </div>
                  </div>

                  {/* Included features in this project */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Recursos Implementados
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {activeModalProject.features.map((feat, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>{feat}</span>
                        </div>
                      ))}
                      <div className="flex items-center gap-2 text-xs text-slate-300">
                        <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>100% responsivo para smartphone</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-300">
                        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Segurança SSL e SEO estruturado</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action in modal */}
                <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-xs text-slate-400 text-center sm:text-left">
                    Gostou deste estilo para o seu segmento?
                  </div>
                  <button
                    onClick={() => {
                      onRequestSimilar(activeModalProject.title, activeModalProject.branch);
                      setActiveModalProject(null);
                    }}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl text-sm font-bold transition-all shadow-xl shadow-blue-950 border border-blue-400/40 active:scale-98 cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-cyan-300" />
                    <span>Quero um site neste estilo</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
