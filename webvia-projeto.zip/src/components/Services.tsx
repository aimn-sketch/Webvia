import { SERVICES } from "../data/agencyData";
import {
  Check,
  Zap,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  Search,
  MessageCircle,
  Clock,
  Sparkles,
} from "lucide-react";

interface ServicesProps {
  onSelectService: (serviceName: string) => void;
}

export function Services({ onSelectService }: ServicesProps) {
  const universalInclusions = [
    { icon: Smartphone, title: "100% Adaptado a Celulares", desc: "Design responsivo que brilha em qualquer tela." },
    { icon: MessageCircle, title: "Botão WhatsApp Inteligente", desc: "Mensagem pré-formatada pronta para converter o cliente." },
    { icon: Search, title: "SEO Estruturado para o Google", desc: "Seu negócio encontrado nas pesquisas locais." },
    { icon: ShieldCheck, title: "Certificado de Segurança SSL", desc: "Navegação segura com cadeado verde oficial." },
    { icon: Clock, title: "Carregamento Ultrarrápido", desc: "Páginas que abrem em menos de 1 segundo." },
    { icon: Zap, title: "Opção Express no Mesmo Dia", desc: "Agilidade máxima para quem tem urgência." },
  ];

  return (
    <section id="servicos" className="py-24 sm:py-32 bg-[#05070D] text-white relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
            <span className="w-8 h-[2px] bg-cyan-400" />
            Nossos Serviços
            <span className="w-8 h-[2px] bg-cyan-400" />
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
            Criação de sites de alto padrão para todos os ramos de atividade.
          </h2>

          <p className="text-lg text-slate-300 leading-relaxed font-normal">
            Não importa o tamanho ou o segmento do seu negócio: entregamos a solução digital sob medida para você
            conquistar autoridade e gerar mais faturamento todos os dias.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {SERVICES.map((service) => {
            const isHighlight = service.highlight;
            return (
              <div
                key={service.id}
                className={`rounded-2xl p-8 flex flex-col justify-between transition-all duration-300 relative group ${
                  isHighlight
                    ? "bg-gradient-to-b from-[#0B1A30] via-[#071120] to-[#040812] text-white shadow-2xl border-2 border-blue-400/50 hover:border-cyan-300/80"
                    : "bg-[#0A0F1D] text-white border border-white/10 hover:border-blue-500/40 shadow-xl hover:shadow-2xl hover:shadow-black/80"
                }`}
              >
                {/* Highlight ribbon or speed badge */}
                <div className="flex items-center justify-between gap-2 mb-6">
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full ${
                      isHighlight
                        ? "bg-blue-500/20 text-cyan-300 border border-blue-400/30"
                        : "bg-blue-950/60 text-blue-300 border border-blue-800/40"
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    {service.deliverySpeed}
                  </span>

                  {isHighlight && (
                    <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Mais Procurado
                    </span>
                  )}
                </div>

                {/* Content */}
                <div className="space-y-4 mb-8">
                  <h3 className="text-2xl font-bold font-display tracking-tight text-white">
                    {service.title}
                  </h3>

                  <p
                    className={`text-sm font-medium leading-snug ${
                      isHighlight ? "text-cyan-200" : "text-blue-400"
                    }`}
                  >
                    {service.tagline}
                  </p>

                  <p className="text-sm leading-relaxed text-slate-300">
                    {service.description}
                  </p>

                  {/* Branches target */}
                  <div className="pt-2">
                    <span className="text-[11px] uppercase font-bold tracking-wider block mb-2 text-slate-400">
                      Ideal para:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {service.targetBranches.map((branch, i) => (
                        <span
                          key={i}
                          className="text-xs px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-200 font-medium"
                        >
                          {branch}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Deliverables Checklist */}
                  <div className="pt-4 border-t border-white/10 space-y-2.5">
                    <span className="text-xs font-semibold block text-slate-300">
                      O que está incluso:
                    </span>
                    {service.deliverables.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs">
                        <Check className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                        <span className="text-slate-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card CTA Button */}
                <button
                  onClick={() => onSelectService(service.title)}
                  className={`w-full py-3.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isHighlight
                      ? "bg-blue-600 hover:bg-blue-500 text-white shadow-xl shadow-blue-950 border border-blue-400/40 active:scale-98"
                      : "bg-black hover:bg-blue-600 text-white border border-white/20 hover:border-blue-500 shadow-md active:scale-98"
                  }`}
                >
                  <span>Solicitar este site</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Universal Standard Inclusions Bar */}
        <div className="rounded-3xl bg-[#0A0F1D] border border-white/10 p-8 sm:p-12 shadow-2xl">
          <div className="max-w-2xl mx-auto text-center space-y-2 mb-10">
            <h3 className="text-2xl font-bold text-white font-display">
              Padrão de Qualidade Incluso em Todo Site Webvia
            </h3>
            <p className="text-sm text-slate-400">
              Não cobramos adicionais por recursos essenciais. Seu site já é entregue 100% completo e operacional.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {universalInclusions.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div key={idx} className="flex items-start gap-4 p-4 rounded-xl bg-[#05070D] border border-white/5 hover:border-blue-500/30 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-blue-950/80 border border-blue-500/30 text-white flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5 text-cyan-300" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white">{item.title}</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
