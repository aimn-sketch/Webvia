import { useState } from "react";
import { SECTORS, AGENCY_INFO } from "../data/agencyData";
import { Calculator, Check, Zap, ArrowRight, Sparkles } from "lucide-react";

interface ProjectSimulatorProps {
  onApplySimulation: (sector: string, projectType: string, urgency: "normal" | "express") => void;
}

export function ProjectSimulator({ onApplySimulation }: ProjectSimulatorProps) {
  const [selectedSector, setSelectedSector] = useState(SECTORS[0]);
  const [projectType, setProjectType] = useState<"landing" | "institucional" | "ecommerce" | "agendamento">("landing");
  const [deliverySpeed, setDeliverySpeed] = useState<"normal" | "express">("express");

  const projectTypes = [
    { id: "landing" as const, name: "Landing Page de Alta Conversão", desc: "Focada em anúncios e vendas diretas" },
    { id: "institucional" as const, name: "Site Institucional Completo", desc: "Autoridade corporativa e múltiplas páginas" },
    { id: "ecommerce" as const, name: "Loja Virtual / Catálogo PIX", desc: "Venda de produtos e checkout ágil" },
    { id: "agendamento" as const, name: "Site com Agendamento Online", desc: "Agenda integrada para consultas e serviços" },
  ];

  const addonsList = [
    { id: "whatsapp", label: "Botão WhatsApp Inteligente com mensagem pré-pronta", included: true },
    { id: "mobile", label: "Otimização Extrema para Smartphones", included: true },
    { id: "seo", label: "Indexação e SEO Estruturado no Google", included: true },
    { id: "ssl", label: "Certificado de Segurança SSL e Hospedagem Rápida", included: true },
  ];

  const handleApply = () => {
    const typeLabel = projectTypes.find((p) => p.id === projectType)?.name || "Landing Page";
    onApplySimulation(selectedSector, typeLabel, deliverySpeed);

    const contactEl = document.getElementById("contato");
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="py-20 bg-[#070B14] text-white border-y border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
            <Calculator className="w-4 h-4" />
            Simulador de Projeto
          </div>
          <h3 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Monte a estrutura ideal para a sua empresa
          </h3>
          <p className="text-xs sm:text-sm text-slate-300">
            Descubra a combinação perfeita de recursos para o seu ramo e solicite com 1 clique.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-[#0A0F1D] rounded-3xl p-6 sm:p-10 border border-white/10 shadow-2xl space-y-8">
          {/* Step 1: Sector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              1. Selecione o Ramo da sua Empresa:
            </label>
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-[#03060C] border border-white/20 text-white font-medium text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 cursor-pointer"
            >
              {SECTORS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Step 2: Project Type */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              2. Qual formato de site você precisa?
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {projectTypes.map((type) => (
                <div
                  key={type.id}
                  onClick={() => setProjectType(type.id)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    projectType === type.id
                      ? "bg-blue-950/60 border-blue-400 ring-2 ring-blue-400/40 text-white"
                      : "bg-[#03060C] border-white/10 hover:border-white/20 text-slate-300"
                  }`}
                >
                  <div className="font-bold text-sm text-white">{type.name}</div>
                  <div className="text-xs text-slate-300 mt-0.5">{type.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Step 3: Speed option */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              3. Prazo Desejado:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => setDeliverySpeed("express")}
                className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                  deliverySpeed === "express"
                    ? "bg-amber-950/30 border-amber-400 ring-2 ring-amber-400/40 text-white"
                    : "bg-[#03060C] border-white/10 hover:border-amber-400/40 text-slate-300"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <div>
                    <span className="font-bold text-sm text-amber-300 block">
                      ⚡ Entrega no Mesmo Dia (Express)
                    </span>
                    <span className="text-[11px] text-slate-300">Prioridade absoluta na produção</span>
                  </div>
                </div>
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${deliverySpeed === "express" ? "border-amber-400 bg-amber-400" : "border-slate-500"}`}>
                  {deliverySpeed === "express" && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                </div>
              </div>

              <div
                onClick={() => setDeliverySpeed("normal")}
                className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                  deliverySpeed === "normal"
                    ? "bg-blue-950/50 border-cyan-400 ring-2 ring-cyan-400/40 text-white"
                    : "bg-[#03060C] border-white/10 hover:border-blue-400/40 text-slate-300"
                }`}
              >
                <div>
                  <span className="font-bold text-sm text-white block">
                    Prazo Normal (1 a 3 dias úteis)
                  </span>
                  <span className="text-[11px] text-slate-400">Fluxo tradicional de revisão</span>
                </div>
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${deliverySpeed === "normal" ? "border-cyan-400 bg-cyan-400" : "border-slate-500"}`}>
                  {deliverySpeed === "normal" && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                </div>
              </div>
            </div>
          </div>

          {/* Included Features Summary */}
          <div className="pt-4 border-t border-white/10 space-y-2">
            <span className="text-xs font-semibold text-slate-400 block">
              Recursos já garantidos na sua simulação:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
              {addonsList.map((addon) => (
                <div key={addon.id} className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{addon.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            <button
              onClick={handleApply}
              className="w-full py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-base shadow-xl shadow-blue-950 border border-blue-400/40 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              <Sparkles className="w-4 h-4 text-cyan-300" />
              <span>{AGENCY_INFO.mainCta} com esta configuração</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
