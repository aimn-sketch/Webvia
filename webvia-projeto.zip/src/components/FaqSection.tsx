import { useState } from "react";
import { FAQS, HOW_IT_WORKS } from "../data/agencyData";
import { ChevronDown, HelpCircle } from "lucide-react";

export function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="diferenciais" className="py-24 sm:py-32 bg-[#05070D] text-white relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* How it works in 4 simple steps */}
        <div className="mb-24">
          <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
              <span className="w-8 h-[2px] bg-cyan-400" />
              Como Funciona
              <span className="w-8 h-[2px] bg-cyan-400" />
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight">
              Do zero ao site no ar em 4 passos simples.
            </h2>

            <p className="text-sm sm:text-base text-slate-300">
              Processo desburocratizado para você focar no que mais importa: atender seus novos clientes.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {HOW_IT_WORKS.map((step) => (
              <div
                key={step.step}
                className="p-6 rounded-2xl bg-[#0A0F1D] border border-white/10 hover:border-blue-500/40 transition-all space-y-3 relative group hover:shadow-2xl hover:shadow-black/80"
              >
                <div className="text-4xl font-extrabold text-white/10 group-hover:text-blue-500/30 transition-colors font-display">
                  {step.step}
                </div>
                <h3 className="text-lg font-bold text-white font-display leading-snug">
                  {step.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          <div className="text-center space-y-3 mb-12">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              Perguntas Frequentes
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              Tudo o que você precisa saber antes de começar.
            </h3>
          </div>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => {
              const isOpen = openIndex === idx;
              return (
                <div
                  key={idx}
                  className="rounded-2xl border border-white/10 bg-[#0A0F1D] overflow-hidden transition-all duration-200"
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 font-bold text-white hover:text-cyan-300 transition-colors focus-visible:outline-blue-500 cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-base sm:text-lg font-display">{faq.question}</span>
                    <ChevronDown
                      className={`w-5 h-5 shrink-0 text-slate-400 transition-transform duration-200 ${
                        isOpen ? "rotate-180 text-cyan-400" : ""
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-6 sm:px-6 pt-0 text-sm text-slate-300 leading-relaxed border-t border-white/5 bg-[#03060C]">
                      <p className="pt-4">{faq.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
