import { TESTIMONIALS } from "../data/agencyData";
import { Star, TrendingUp, CheckCircle, ShieldCheck } from "lucide-react";

export function Testimonials() {
  return (
    <section id="depoimentos" className="py-24 sm:py-32 bg-[#05070D] text-white relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
            <span className="w-8 h-[2px] bg-cyan-400" />
            Depoimentos Reais
            <span className="w-8 h-[2px] bg-cyan-400" />
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
            Quem confiou na Webvia já está colhendo resultados.
          </h2>

          <p className="text-lg text-slate-300 leading-relaxed font-normal">
            Histórias reais de donos de negócios e profissionais que transformaram sua presença digital em uma fonte
            contínua de novos clientes e faturamento.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="rounded-3xl bg-[#0A0F1D] border border-white/10 p-8 sm:p-10 shadow-xl hover:shadow-2xl hover:border-blue-500/40 transition-all duration-300 flex flex-col justify-between relative group"
            >
              <div className="space-y-6">
                {/* Top Row: Stars & Sector */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>

                  <span className="text-[11px] font-semibold text-slate-300 bg-white/5 border border-white/10 px-3 py-1 rounded-full">
                    {item.branch}
                  </span>
                </div>

                {/* Quote Text */}
                <p className="text-slate-200 text-sm sm:text-base leading-relaxed italic">
                  “{item.content}”
                </p>

                {/* Metric Box */}
                <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-2.5 text-xs font-bold text-emerald-300">
                  <TrendingUp className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>Resultado: {item.result}</span>
                </div>
              </div>

              {/* Author Info */}
              <div className="pt-6 mt-6 border-t border-white/10 flex items-center gap-4">
                <img
                  src={item.avatar}
                  alt={item.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-white/20"
                  loading="lazy"
                />
                <div>
                  <h4 className="text-sm font-bold text-white">{item.name}</h4>
                  <p className="text-xs text-slate-400 font-medium">
                    {item.role} • <strong className="text-slate-200">{item.company}</strong>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust & Guarantee Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-[#020408] via-[#07101E] to-[#0A1A33] border border-blue-500/30 text-white p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-14 h-14 rounded-2xl bg-blue-950/80 border border-blue-500/30 flex items-center justify-center shrink-0 mx-auto md:mx-0">
              <ShieldCheck className="w-8 h-8 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-bold font-display text-white">
                Garantia de Satisfação e Suporte Webvia
              </h3>
              <p className="text-xs sm:text-sm text-slate-300">
                Você só aprova o site quando cada detalhe estiver exatamente como você imaginou. Ajustes rápidos inclusos.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6 shrink-0 text-xs sm:text-sm text-slate-300">
            <span className="flex items-center gap-2 font-medium">
              <CheckCircle className="w-4 h-4 text-emerald-400" /> 100% de Clientes Satisfeitos
            </span>
            <span className="flex items-center gap-2 font-medium">
              <CheckCircle className="w-4 h-4 text-emerald-400" /> Suporte no WhatsApp
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
