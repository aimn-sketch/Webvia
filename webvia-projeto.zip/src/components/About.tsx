import { AGENCY_INFO } from "../data/agencyData";
import {
  Sparkles,
  Zap,
  Target,
  CheckCircle,
  XCircle,
  Shield,
  ArrowRight,
} from "lucide-react";

interface AboutProps {
  onStartProject: () => void;
}

export function About({ onStartProject }: AboutProps) {
  const comparisonList = [
    {
      feature: "Prazo de Entrega",
      traditional: "30 a 60 dias de espera e atrasos constantes",
      webvia: "Entrega no mesmo dia ou em até poucas horas",
    },
    {
      feature: "Foco do Projeto",
      traditional: "Apenas 'layout bonito' sem estratégia de vendas",
      webvia: "Estrutura focada em conversão e geração de faturamento",
    },
    {
      feature: "Ramos Atendidos",
      traditional: "Ficam presos a modelos genéricos e engessados",
      webvia: "Especialista em entender as particularidades de cada ramo",
    },
    {
      feature: "Comunicação",
      traditional: "Plataformas complexas de tickets e burocracia",
      webvia: "Atendimento ágil e direto pelo WhatsApp",
    },
    {
      feature: "Propriedade",
      traditional: "Mensalidades abusivas para manter o site no ar",
      webvia: "Site 100% seu, sem contratos de fidelidade forçados",
    },
  ];

  return (
    <section id="sobre" className="py-24 sm:py-32 bg-black text-white relative overflow-hidden border-t border-white/5">
      {/* Decorative background grid pattern */}
      <div className="absolute inset-0 grid-bg-pattern opacity-10 pointer-events-none" />
      <div className="absolute top-1/3 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
            <span className="w-8 h-[2px] bg-cyan-400" />
            Sobre a Webvia
            <span className="w-8 h-[2px] bg-cyan-400" />
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
            Nascemos para conectar negócios ao seu verdadeiro potencial na internet.
          </h2>
          
          <p className="text-lg text-slate-300 leading-relaxed font-normal pt-2">
            Eliminamos os prazos intermináveis e a complicação técnica para que sua empresa tenha uma presença online
            digna dos maiores líderes de mercado.
          </p>
        </div>

        {/* The Central Purpose Quote Box */}
        <div className="mb-20 rounded-3xl bg-gradient-to-br from-[#020408] via-[#050B17] to-[#0A162B] text-white p-8 sm:p-14 shadow-2xl border border-blue-500/25 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
            <div className="inline-flex p-3 rounded-2xl bg-blue-500/10 text-cyan-300 border border-blue-500/20 mx-auto">
              <Sparkles className="w-6 h-6" />
            </div>

            <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-bold font-display text-white tracking-tight leading-snug">
              “{AGENCY_INFO.aboutText}”
            </blockquote>

            <p className="text-slate-300 text-sm sm:text-base font-normal max-w-2xl mx-auto">
              Não importa se você é uma clínica médica, um restaurante conceituado, um escritório de advocacia ou um
              comércio local: seu cliente está pesquisando por você agora. Se o seu site não passar credibilidade
              imediata, ele comprará do seu concorrente.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300">
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                Sem termos técnicos complicados
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                Entrega com velocidade recorde
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                Atendimento humanizado em todo o Brasil
              </span>
            </div>
          </div>
        </div>

        {/* 3 Core Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
          <div className="p-8 rounded-2xl bg-[#06080F] border border-white/10 hover:border-blue-500/40 transition-all duration-300 group hover:shadow-2xl hover:shadow-black/90">
            <div className="w-12 h-12 rounded-xl bg-blue-950/80 border border-blue-500/30 text-white flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
              <Zap className="w-6 h-6 text-amber-400" />
            </div>
            <h3 className="text-xl font-bold text-white font-display mb-3">
              Entrega no Mesmo Dia
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed">
              Sabemos que cada dia sem um site profissional é dinheiro deixado na mesa. Nossa metodologia ágil permite
              construir, revisar e publicar sua página em tempo recorde sem sacrificar um milímetro de sofisticação.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-[#06080F] border border-white/10 hover:border-blue-500/40 transition-all duration-300 group hover:shadow-2xl hover:shadow-black/90">
            <div className="w-12 h-12 rounded-xl bg-blue-950/80 border border-blue-500/30 text-white flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
              <Target className="w-6 h-6 text-cyan-300" />
            </div>
            <h3 className="text-xl font-bold text-white font-display mb-3">
              Especialistas em Qualquer Ramo
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed">
              Cada setor possui um comportamento de compra específico. Analisamos detalhadamente as dores do seu público
              para criar gatilhos visuais e chamadas de ação precisas para o seu nicho de atuação.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-[#06080F] border border-white/10 hover:border-blue-500/40 transition-all duration-300 group hover:shadow-2xl hover:shadow-black/90">
            <div className="w-12 h-12 rounded-xl bg-blue-950/80 border border-blue-500/30 text-white flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
              <Shield className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold text-white font-display mb-3">
              Foco em Faturamento Real
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed">
              O objetivo do seu site é gerar caixa. Posicionamos botões de WhatsApp, formulários intuitivos e argumentos
              de vendas que conduzem o visitante diretamente ao fechamento de negócio.
            </p>
          </div>
        </div>

        {/* Side-by-side comparison: Agência Tradicional vs Webvia */}
        <div className="rounded-3xl border border-white/10 bg-[#06080F] p-6 sm:p-10 shadow-2xl">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <h3 className="text-2xl sm:text-3xl font-bold text-white font-display">
              Por que a Webvia é a escolha inteligente?
            </h3>
            <p className="text-slate-400 text-sm">
              Veja a diferença prática entre o modelo ultrapassado do mercado e a nossa entrega de alto padrão.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" role="table" aria-label="Comparativo de serviços">
              <thead>
                <tr className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-400">
                  <th className="py-4 px-4 font-semibold">Critério</th>
                  <th className="py-4 px-4 font-semibold text-slate-500">Agências Tradicionais</th>
                  <th className="py-4 px-4 font-semibold text-white bg-[#061324] rounded-t-lg border-t border-x border-blue-500/30">
                    Padrão Webvia
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm">
                {comparisonList.map((row, idx) => (
                  <tr key={idx} className="hover:bg-white/5 transition-colors">
                    <td className="py-4 px-4 font-medium text-white">{row.feature}</td>
                    <td className="py-4 px-4 text-slate-400 flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{row.traditional}</span>
                    </td>
                    <td className="py-4 px-4 font-semibold text-white bg-[#061324]/80 border-x border-blue-500/20">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{row.webvia}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-8 text-center pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <span className="text-sm text-slate-300 font-medium">
              Pronto para transformar a presença digital da sua empresa?
            </span>
            <button
              onClick={onStartProject}
              className="inline-flex items-center gap-2 text-sm font-bold text-white hover:text-cyan-300 underline underline-offset-4 cursor-pointer"
            >
              <span>{AGENCY_INFO.mainCta}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
