import { useState, FormEvent } from "react";
import { AGENCY_INFO, SECTORS } from "../data/agencyData";
import confetti from "canvas-confetti";
import {
  Send,
  MessageSquare,
  Zap,
  CheckCircle2,
  Clock,
  Sparkles,
  Phone,
  Instagram,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";

interface ContactSectionProps {
  initialService?: string;
  initialSector?: string;
}

export function ContactSection({ initialService, initialSector }: ContactSectionProps) {
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [phone, setPhone] = useState("");
  const [sector, setSector] = useState(initialSector || SECTORS[0]);
  const [urgency, setUrgency] = useState<"normal" | "express">("normal");
  const [details, setDetails] = useState("");
  const [submitted, setSubmitted] = useState(false);

  // If initialSector updates from outside:
  if (initialSector && sector !== initialSector && !submitted) {
    setSector(initialSector);
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // fallback
    }

    setSubmitted(true);

    // Prepare WhatsApp message payload for the user's agency
    const isExpress = urgency === "express";
    const textMessage = `*Novo Projeto - Webvia*%0A%0A` +
      `*Nome:* ${encodeURIComponent(name)}%0A` +
      `*Empresa:* ${encodeURIComponent(company || "Não informado")}%0A` +
      `*Telefone / WhatsApp:* ${encodeURIComponent(phone)}%0A` +
      `*Ramo de Atuação:* ${encodeURIComponent(sector)}%0A` +
      `*Prazo Solicitado:* ${isExpress ? "⚡ ENTREGA NO MESMO DIA (URGENTE)" : "Padrão (1 a 3 dias)"}%0A` +
      (initialService ? `*Serviço de Interesse:* ${encodeURIComponent(initialService)}%0A` : "") +
      `*Detalhes:* ${encodeURIComponent(details || "Gostaria de um orçamento detalhado.")}`;

    // Auto open WhatsApp with the formatted brief after brief delay
    const whatsappUrl = `https://wa.me/${AGENCY_INFO.whatsappNumber}?text=${textMessage}`;
    setTimeout(() => {
      window.open(whatsappUrl, "_blank", "noopener,noreferrer");
    }, 1200);
  };

  const handleReset = () => {
    setSubmitted(false);
    setName("");
    setCompany("");
    setPhone("");
    setDetails("");
  };

  return (
    <section id="contato" className="py-24 sm:py-32 bg-[#05070D] text-white relative overflow-hidden border-t border-white/5">
      {/* Background radial glow */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute inset-0 dark-grid-pattern opacity-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Persuasive copy and direct contact channels */}
          <div className="lg:col-span-5 space-y-8">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-cyan-400 uppercase">
              <span className="w-8 h-[2px] bg-cyan-400" />
              Solicite Seu Orçamento
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display text-white tracking-tight leading-tight">
              {AGENCY_INFO.mainCta}.
            </h2>

            <p className="text-base text-slate-300 leading-relaxed">
              Preencha o formulário em menos de 1 minuto para receber uma proposta personalizada para a sua empresa. Se
              tiver urgência, selecione a opção de <strong>Entrega no Mesmo Dia</strong>.
            </p>

            {/* Direct Contact Cards */}
            <div className="space-y-4 pt-2">
              <a
                href={`https://wa.me/${AGENCY_INFO.whatsappNumber}?text=${encodeURIComponent(
                  AGENCY_INFO.whatsappDefaultMessage
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-2xl bg-[#0A0F1D] border border-white/10 hover:border-emerald-400/50 transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400 font-medium">WhatsApp Oficial</div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{AGENCY_INFO.whatsappDisplay}</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-normal">
                      Online Agora
                    </span>
                  </div>
                </div>
              </a>

              <a
                href={AGENCY_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-2xl bg-[#0A0F1D] border border-white/10 hover:border-pink-400/50 transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <Instagram className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400 font-medium">Instagram Oficial</div>
                  <div className="text-sm font-bold text-white">{AGENCY_INFO.instagramHandle}</div>
                </div>
              </a>
            </div>

            {/* Quick Guarantees */}
            <div className="pt-4 border-t border-white/10 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Seus dados estão protegidos. Não enviamos spam.</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Retorno médio em menos de 15 minutos em horário comercial.</span>
              </div>
            </div>
          </div>

          {/* Right Column: High-Converting Form in Deep Obsidian Black */}
          <div className="lg:col-span-7">
            <div className="bg-[#0A0F1D] text-white rounded-3xl p-8 sm:p-10 shadow-2xl border border-white/10">
              {submitted ? (
                <div className="py-12 text-center space-y-6 animate-in zoom-in-95 duration-300">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-extrabold text-white font-display">
                      Proposta Enviada com Sucesso!
                    </h3>
                    <p className="text-slate-300 text-sm max-w-md mx-auto">
                      Estamos abrindo o WhatsApp para conectar você diretamente a um dos nossos especialistas em
                      criação de sites.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#03060C] border border-white/10 text-xs text-slate-300 max-w-md mx-auto space-y-1">
                    <div>
                      <strong className="text-white">Ramo selecionado:</strong> {sector}
                    </div>
                    <div>
                      <strong className="text-white">Prazo:</strong> {urgency === "express" ? "⚡ Entrega no mesmo dia" : "Padrão"}
                    </div>
                  </div>

                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                    <a
                      href={`https://wa.me/${AGENCY_INFO.whatsappNumber}?text=Olá Webvia! Acabei de enviar meu formulário para o ramo ${encodeURIComponent(
                        sector
                      )}.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 px-6 py-3 rounded-xl font-bold text-sm shadow-md"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Conversar no WhatsApp Agora</span>
                    </a>

                    <button
                      onClick={handleReset}
                      className="text-xs text-slate-400 hover:text-white font-semibold underline cursor-pointer"
                    >
                      Enviar outra solicitação
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="border-b border-white/10 pb-4">
                    <h3 className="text-xl font-bold text-white font-display">
                      Dados do Seu Projeto
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Preencha os campos abaixo para desenharmos a estrutura ideal do seu site.
                    </p>
                  </div>

                  {/* Name and Company */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-xs font-bold text-slate-300 mb-1">
                        Seu Nome Completo *
                      </label>
                      <input
                        type="text"
                        id="name"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Ex: Carlos Eduardo"
                        className="w-full px-4 py-3 rounded-xl bg-[#03060C] border border-white/15 focus:outline-none focus:ring-2 focus:ring-cyan-400 text-sm text-white placeholder:text-slate-500"
                      />
                    </div>

                    <div>
                      <label htmlFor="company" className="block text-xs font-bold text-slate-300 mb-1">
                        Nome da Empresa ou Negócio
                      </label>
                      <input
                        type="text"
                        id="company"
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        placeholder="Ex: Clínica Bem Estar / Restaurante Sabor"
                        className="w-full px-4 py-3 rounded-xl bg-[#03060C] border border-white/15 focus:outline-none focus:ring-2 focus:ring-cyan-400 text-sm text-white placeholder:text-slate-500"
                      />
                    </div>
                  </div>

                  {/* Phone & Sector */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="phone" className="block text-xs font-bold text-slate-300 mb-1">
                        WhatsApp para Contato *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="(73) 98242-3074"
                        className="w-full px-4 py-3 rounded-xl bg-[#03060C] border border-white/15 focus:outline-none focus:ring-2 focus:ring-cyan-400 text-sm text-white placeholder:text-slate-500"
                      />
                    </div>

                    <div>
                      <label htmlFor="sector" className="block text-xs font-bold text-slate-300 mb-1">
                        Ramo de Atuação do Negócio *
                      </label>
                      <select
                        id="sector"
                        value={sector}
                        onChange={(e) => setSector(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl bg-[#03060C] border border-white/15 focus:outline-none focus:ring-2 focus:ring-cyan-400 text-sm text-white cursor-pointer"
                      >
                        {SECTORS.map((sec) => (
                          <option key={sec} value={sec} className="bg-[#03060C] text-white">
                            {sec}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Speed/Urgency Selection Card */}
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-2">
                      Qual é o seu prazo ideal?
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div
                        onClick={() => setUrgency("normal")}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          urgency === "normal"
                            ? "border-blue-400 bg-blue-950/40 ring-2 ring-blue-400/40"
                            : "border-white/10 bg-[#03060C] hover:border-white/20"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Clock className="w-4 h-4 text-cyan-400" />
                          <span className="text-xs font-bold text-white">
                            Prazo Normal (1 a 3 dias)
                          </span>
                        </div>
                        <input
                          type="radio"
                          name="urgency"
                          checked={urgency === "normal"}
                          onChange={() => setUrgency("normal")}
                          className="accent-cyan-400"
                        />
                      </div>

                      <div
                        onClick={() => setUrgency("express")}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          urgency === "express"
                            ? "border-amber-400 bg-amber-950/30 ring-2 ring-amber-400/40"
                            : "border-white/10 bg-[#03060C] hover:border-amber-400/40"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Zap className="w-4 h-4 text-amber-400" />
                          <div>
                            <span className="text-xs font-bold text-amber-300 block">
                              ⚡ Entrega no Mesmo Dia
                            </span>
                            <span className="text-[10px] text-amber-200/80">Urgência prioritária</span>
                          </div>
                        </div>
                        <input
                          type="radio"
                          name="urgency"
                          checked={urgency === "express"}
                          onChange={() => setUrgency("express")}
                          className="accent-amber-400"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Message Details */}
                  <div>
                    <label htmlFor="details" className="block text-xs font-bold text-slate-300 mb-1">
                      Conte um pouco sobre suas ideias e objetivos
                    </label>
                    <textarea
                      id="details"
                      rows={3}
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      placeholder="Ex: Preciso de um site para minha clínica com agendamento direto no WhatsApp e fotos dos tratamentos..."
                      className="w-full px-4 py-3 rounded-xl bg-[#03060C] border border-white/15 focus:outline-none focus:ring-2 focus:ring-cyan-400 text-sm text-white placeholder:text-slate-500"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-base shadow-2xl shadow-blue-950 border border-blue-400/40 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
                  >
                    <span>{AGENCY_INFO.mainCta}</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>

                  <div className="text-center">
                    <span className="text-[11px] text-slate-400">
                      🔒 Ao enviar, entraremos em contato diretamente com você sem compromisso financeiro inicial.
                    </span>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
